DROP TABLE IF EXISTS `#__tabapapo`;
DROP TABLE IF EXISTS `#__tabapapo_msg`;
DROP TABLE IF EXISTS `#__tabapapo_usu`;