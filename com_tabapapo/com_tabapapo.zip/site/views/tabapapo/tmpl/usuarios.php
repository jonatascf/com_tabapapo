<?php
/**
 * @package     Tabapapo.Administrator
 * @subpackage  com_tabapapo
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;

?>

<html>
<head>
</head>
<body>
<div id="showusers"></div>
</body>
</html>